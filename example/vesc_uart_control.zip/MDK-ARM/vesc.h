#ifndef VESC_H
#define VESC_H

#include "usart.h"









// CRC Table







#endif

