CMSIS is Copyright (C) 2011-2013 ARM Limited. All rights reserved.

This directory contains only part of the CMSIS package. If you need the whole
package please download it from:

http://www.arm.com
